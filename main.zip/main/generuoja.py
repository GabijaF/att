import random
import time

def generate_graph(num_vertices, num_edges):
    edges = set()
    while len(edges) < num_edges:
        u = random.randint(1, num_vertices)
        v = random.randint(1, num_vertices)
        if u != v:
            edges.add((u, v))
    return list(edges)

def input_graph():
    num_vertices = int(input("Viršūnių kiekis: "))
    num_edges = int(input("Briaunų kiekis: "))
    return generate_graph(num_vertices, num_edges)


def is_iso(graph1, graph2, num_vertices):
    if len(graph1) != len(graph2):
        return False

    def create_adj_dict(edges):
        adj_dict = {i: set() for i in range(1, num_vertices + 1)}
        for u, v in edges:
            adj_dict[u].add(v)
        return adj_dict

    adj_dict1 = create_adj_dict(graph1)
    adj_dict2 = create_adj_dict(graph2)

    def dfs_iso(node, mapping):
        if len(mapping) == num_vertices:
            return all(adj_dict1[v] == {mapping[n] for n in adj_dict2[mapping[v]]} for v in mapping)

        for next_node in range(1, num_vertices + 1):
            if next_node not in mapping.values():
                mapping[node] = next_node
                if dfs_iso(node + 1, mapping):
                    return True
                del mapping[node]

        return False

    return dfs_iso(1, {})

print("1 grafas:")
graph1 = input_graph()
print(f"\nBriaunos: {graph1}")

print("\n2 grafas:")
graph2 = input_graph()
print(f"\nBriaunos: {graph2}")

num_vertices = max(max(u, v) for edge in graph1 + graph2 for u, v in [edge])

start_time = time.time()
result = is_iso(graph1, graph2, num_vertices)
end_time = time.time()

if result:
    print("\nGrafai yra izomorfiški.")
else:
    print("\nGrafai nėra izomorfiški.")

print(f"\nlaikas: {end_time - start_time} sekundės")

input("Press Enter to exit...")