import subprocess

def main():
    print("pasirinkite:")
    print("1. duomenis ivesite patys")
    print("2. generuoti duomenis")

    choice = input("pasirinkimo numeris: ")

    if choice == '1':
        subprocess.run(["python", "ranka.py"], check=True)
    elif choice == '2':
        subprocess.run(["python", "generuoja.py"], check=True)
    else:
        print("blogas pasirinkimas")

if __name__ == "__main__":
    main()