
import time

def input_graph():
    num_vertices = int(input("iveskite virsuniu skaiciu n "))
    graph = {}

    for i in range(1, num_vertices + 1):
        kaimynai = list(map(int, input(f"iveskite su kokiom virsunem jungiasi virsune {i} (su tarpais): ").split()))
        graph[i] = kaimynai

    return graph

 

def ar_grafai_izo(grafas1, grafas2):
    
    if len(grafas1) != len(grafas2):
        return False

    
    laipsniu_sekos1 = sorted(len(kaimynai) for kaimynai in grafas1.values())
    laipsniu_sekos2 = sorted(len(kaimynai) for kaimynai in grafas2.values())

    if laipsniu_sekos1 != laipsniu_sekos2:
        return False

    # dfs su grizimu
    def dfs_izo(node1, mapping):
        if node1 in mapping:
            return mapping[node1]

        for node2 in grafas2:
            if node2 not in mapping and len(grafas1[node1]) == len(grafas2[node2]):
                mapping[node1] = node2

                izo = all(dfs_izo(kaimynas1, mapping) == grafas2[node2][i] for i, kaimynas1 in enumerate(grafas1[node1]))

                if izo:
                    return node2

                del mapping[node1]

        return None

    #dfs
    for start_node in grafas1:
        mapping = {start_node: list(grafas2.keys())[0]}
        result = dfs_izo(start_node, mapping)

        if result is not None:
            return True

    return False
    
 


print("1 grafas")
grafas1 = input_graph()

print("\n2 grafas:")
grafas2 = input_graph()

start_time = time.time()   
result = ar_grafai_izo(grafas1, grafas2)
end_time = time.time()


if result:
    print("\ngrafai izomorfiski.")
else:
    print("\ngrafai nera izomorfiski.")

print(f"\nlaikas: {end_time - start_time} sekundes")    

input("Press Enter to exit...")
